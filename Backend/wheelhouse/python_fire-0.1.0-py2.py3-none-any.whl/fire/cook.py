from __future__ import print_function


def main():
    print ("MMMMM TASTY")
